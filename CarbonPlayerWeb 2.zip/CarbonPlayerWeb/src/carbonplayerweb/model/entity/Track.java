package carbonplayerweb.model.entity;

public class Track {
}
