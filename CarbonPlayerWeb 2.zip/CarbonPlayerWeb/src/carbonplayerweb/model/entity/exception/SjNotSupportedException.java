package carbonplayerweb.model.entity.exception;

public class SjNotSupportedException extends Exception {
}
